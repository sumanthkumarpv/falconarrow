<?php
/**
 * View class for manage user screen
 *
 * @package   Vendo
 * @author    Jeremy Bush <contractfrombelow@gmail.com>
 * @copyright (c) 2010-2011 Jeremy Bush
 * @license   ISC License http://github.com/zombor/Vendo/raw/master/LICENSE
 */

class View_User_Manage extends View_Layout
{
	public $title = 'Manage My Account';
}